"""
版权所有 ©️ ndDora
微信: jiuming744400

本代码仅供个人学习使用，未经授权不得复制、修改或用于商业用途。

Author: ndDora
"""
import pandas as pd
import numpy as np


def dynamic_leverage(equity: pd.Series, *args) -> pd.Series:
    """
    根据资金曲线，动态调整杠杆
    :param equity: 资金曲线
    :param args: 其他参数
    :return: 返回包含 leverage 的数据
    """
    import numpy as np
    import pandas as pd


    # ===== 获取策略参数
    n = int(args[0])

    # 默认nan
    leverage = pd.Series(np.nan, index=equity.index)

    # 计算每一行之前的最高点
    max2here = equity.cummax()
    max2here.name = "max2here"

    # 计算历史最高值到当日的跌幅
    dd2here = (equity - max2here) / max2here
    dd2here.name = "dd2here"

    # 定义杠杆的条件和对应值，根据最大回撤数据分位自己调整
    conditions = [
        dd2here >= -0.0075,
        (dd2here < -0.0075) & (dd2here >= -0.02),
        (dd2here < -0.02) & (dd2here >= -0.04),
        (dd2here < -0.04) & (dd2here >= -0.1),
        dd2here < -0.1
    ]
    choices = [
        1, 1.02, 1.04, 1.08, 1.1
    ]

    # 使用 np.select() 根据条件设置杠杆
    leverage = np.select(conditions, choices, default=np.nan)
    leverage = pd.Series(leverage, index=dd2here.index, name="leverage")

    # 填充择时信号
    leverage.fillna(1, inplace=True)

    return leverage
