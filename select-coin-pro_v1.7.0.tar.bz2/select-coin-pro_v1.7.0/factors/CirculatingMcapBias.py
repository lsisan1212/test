extra_data_dict = {"coin-cap": ["circulating_supply"]}


def signal(*args):
    df = args[0]  # 输入的数据框
    n = args[1]  # 时间窗口（例如20天）
    factor_name = args[2]  # 综合因子的名称

    # 计算流通市值
    df["circulating_mcap"] = df["circulating_supply"] * df["close"]

    # 计算 bias 因子：当前价格与过去 n 天均值的比值
    df["bias"] = df["close"] / df["close"].rolling(n, min_periods=1).mean()

    # 结合市值因子和 bias 因子（例如加权平均）
    df[factor_name] = df["circulating_mcap"] * df["bias"]

    return df
