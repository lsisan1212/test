"""
邢不行™️ 策略分享会
仓位管理框架

版权所有 ©️ 邢不行
微信: xbx6660

本代码仅供个人学习使用，未经授权不得复制、修改或用于商业用途。

Author: 邢不行
"""
import numpy as np


def signal(*args):
    df = args[0]
    n = args[1]
    factor_name = args[2]
    
    # 计算均价和涨跌幅
    df['均价'] = (df['close'] + df['high'] + df['low']) / 3
    df['涨跌幅'] = df['均价'].pct_change()

    # 计算上涨的稳定性：上涨天数占比
    df['上涨信号'] = np.where(df['涨跌幅'] > 0, 1, 0)
    df['上涨天数'] = df['上涨信号'].rolling(window=n, min_periods=1).sum()
    df['上涨占比'] = df['上涨天数'] / n

    # 计算上涨的均匀性：涨跌幅的标准差（越小越均匀）
    df['涨跌幅标准差'] = df['涨跌幅'].rolling(window=n, min_periods=1).std()

    # 计算稳定上涨指标：上涨占比高且标准差小的币种更稳定
    df['稳定上涨指标'] = df['上涨占比'] / (df['涨跌幅标准差'] + 0.001)  # 加0.001避免除以0

    # 对稳定上涨指标进行时序排名，值越大排名越高
    df[factor_name] = df['稳定上涨指标'].rolling(n, min_periods=1).rank(ascending=False, pct=True)

    return df