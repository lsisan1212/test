"""
邢不行™️ 策略分享会
仓位管理框架

版权所有 ©️ 邢不行
微信: xbx6660

本代码仅供个人学习使用，未经授权不得复制、修改或用于商业用途。

Author: 邢不行
"""
import numpy as np


def signal(*args):
    df = args[0]
    n = args[1]
    factor_name = args[2]

    df['均价'] = (df['close'] + df['high'] + df['low']) / 3

    df['涨跌幅'] = df['均价'].pct_change()
    # 计算下跌信号
    df['下跌信号'] = np.where(df['涨跌幅'] < 0, 1, 0)
    df['下跌天数'] = df['下跌信号'].rolling(window=n, min_periods=1).sum()

    # 计算振幅
    df['振幅'] = (df['high'] - df['low']) / df['open']

    # 计算下跌时的振幅
    df['下跌振幅'] = np.where(df['涨跌幅'] < 0, df['振幅'], 0)
    df['下跌振幅均值'] = df['下跌振幅'].rolling(n, min_periods=1).mean()

    # 计算下跌天数占比
    df['下跌占比'] = df['下跌天数'] / n

    # 综合考虑下跌振幅和下跌天数
    # 下跌振幅小且下跌天数多的币种更适合做空
    df['综合指标'] = df['下跌振幅均值'] * (1 - df['下跌占比'])

    # 对综合指标进行时序排名，值越小排名越高
    df[factor_name] = df['综合指标'].rolling(n, min_periods=1).rank(ascending=True, pct=True)

    return df