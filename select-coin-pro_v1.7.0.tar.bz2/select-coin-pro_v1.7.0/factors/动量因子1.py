def signal(*args):
    df = args[0]
    n = args[1]
    factor_name = args[2]

    df['max_high'] = df['high'].rolling(n, min_periods=1).max()
    df['min_low'] = df['low'].rolling(n, min_periods=1).min()
    df[factor_name] = (df['close'] - df['min_low']) / \
        (df['max_high'] - df['min_low'])

    return df
