# MaxDrawdown.py
"""
邢不行™️ 策略分享会
仓位管理框架

版权所有 ©️ 邢不行
微信: xbx6660

本代码仅供个人学习使用，未经授权不得复制、修改或用于商业用途。

Author: 邢不行
"""
import numpy as np
import pandas as pd

def signal(*args):
    df = args[0]
    n = args[1]
    factor_name = args[2]

    # 计算滚动最大值
    df['rolling_max'] = df['close'].rolling(n, min_periods=1).max()
    # 计算最大回撤
    df['max_drawdown'] = (df['close'] - df['rolling_max']) / df['rolling_max']

    df[factor_name] = df['max_drawdown']

    return df
