from __future__ import annotations

import math


def signal(*args):
    df = args[0]
    n = args[1]
    factor_name = args[2]

    price_change = df["high"] - df["low"].shift(1) / (df["high"].shift(1) - df["low"].shift(2)) - 1
    volume_corr = df["quote_volume"].diff() * df["quote_volume"].diff().shift()
    df[factor_name] = (price_change.abs() / volume_corr.abs()).rolling(n, min_periods=2).mean()

    return df
